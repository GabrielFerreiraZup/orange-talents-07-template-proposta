package br.com.zup.orange.propostas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PropostasApplicationTests {

	@Test
	void contextLoads() {
	}

}
